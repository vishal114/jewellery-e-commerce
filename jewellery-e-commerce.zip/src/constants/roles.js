export const ADMIN = 'ADMIN';
export const MANUFACTURER = 'MANUFACTURER';
export const RETAILER = 'RETAILER';
export const USER = 'USER';