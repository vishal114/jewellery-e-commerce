import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { compose } from 'recompose';
import { withFirebase } from '../Firebase';
import * as ROUTES from '../../constants/routes';
import * as ROLES from '../../constants/roles';
import { Button, TextField } from '@material-ui/core';

const SignUpPage = () => (
  <div>
    <h1>SignUp</h1>
    <SignUpForm />
  </div>
);

const INITIAL_STATE = {
  username: '',
  email: '',
  mobile: '',
  passwordOne: '',
  passwordTwo: '',
  isAdmin: false,
  isManufacturer: false,
  isRetailer: false,
  error: null,
};

class SignUpFormBase extends Component {
  constructor(props) {
    super(props);

    this.state = { ...INITIAL_STATE };
  }
  onChangeCheckbox = event => {
    this.setState({ [event.target.name]: event.target.checked });
    };
  onSubmit = event => {
    const { username, email, mobile, passwordOne, isAdmin, isManufacturer, isRetailer  } = this.state;

    const roles = [];

    if (isAdmin) {
      roles.push(ROLES.ADMIN);
    }
    else if (isManufacturer) {
      roles.push(ROLES.MANUFACTURER);
    }
    else if (isRetailer) {
      roles.push(ROLES.RETAILER);
    }

    this.props.firebase
      .doCreateUserWithEmailAndPassword(email, passwordOne)
      .then(authUser => {
        // Create a user in your Firebase realtime database
        this.props.firebase
          .user(authUser.user.uid)
          .set({
            username,
            email,
            mobile,
            roles,
          })
          .then(() => {
            this.setState({ ...INITIAL_STATE });
            this.props.history.push(ROUTES.HOME);
          })
          .catch(error => {
            this.setState({ error });
          });
      })
      .catch(error => {
        this.setState({ error });
      });

    event.preventDefault();
  };

  onChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  };

  render() {
    const {
      username,
      email,
      mobile,
      passwordOne,
      passwordTwo,
      isAdmin,
      isManufacturer,
      isRetailer,
      error,
    } = this.state;

    const isInvalid =
      passwordOne !== passwordTwo ||
      passwordOne === '' ||
      email === '' ||
      username === '';

    return (
      <form onSubmit={this.onSubmit}>
        <TextField
          name="username"
          value={username}
          onChange={this.onChange}
          type="text"
          placeholder="Full Name"
        /><br/>
        <br/>
        <TextField
          name="email"
          value={email}
          onChange={this.onChange}
          type="text"
          placeholder="Email Address"
        /><br/>
        <br/>
        <TextField
          name="mobile"
          value={mobile}
          onChange={this.onChange}
          type="number"
          placeholder="Mobile number"
        /><br/>
        <br/>
        <TextField
          name="passwordOne"
          value={passwordOne}
          onChange={this.onChange}
          type="password"
          placeholder="Password"
        /><br/>
        <br/>
        <TextField
          name="passwordTwo"
          value={passwordTwo}
          onChange={this.onChange}
          type="password"
          placeholder="Confirm Password"
        /><br/>
        <br/>
        <label>
        Admin:
        <input
        name="isAdmin"
        type="checkbox"
        checked={isAdmin}
        onChange={this.onChangeCheckbox}
        />
        </label>
        <label>
        Manufacturer:
        <input
        name="isManufacturer"
        type="checkbox"
        checked={isManufacturer}
        onChange={this.onChangeCheckbox}
        />
        </label>
        <label>
        Retailer:
        <input
        name="isRetailer"
        type="checkbox"
        checked={isRetailer}
        onChange={this.onChangeCheckbox}
        />
        </label>
        <br/>
        <br/>
        <Button disabled={isInvalid} type="submit" variant="contained" color="primary">
        Sign Up!
        </Button>

        {error && <p>{error.message}</p>}
      </form>
    );
  }
}

const SignUpLink = () => (
  <p>
    Don't have an account? <Link to={ROUTES.SIGN_UP}>Sign Up</Link>
  </p>
);

const SignUpForm = withRouter(withFirebase(SignUpFormBase));

export default SignUpPage;

export { SignUpForm, SignUpLink };
