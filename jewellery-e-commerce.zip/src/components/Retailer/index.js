import React, { Component } from 'react';

import { AuthUserContext, withAuthorization } from '../Session';
import * as ROLES from '../../constants/roles';
import { withFirebase } from '../Firebase';
import { Button } from 'react-bootstrap';

const RetailerPage = () => (
  <div>
    <h1>Retailer Page</h1>
    <p>The Retailer Page is accessible.</p>
    <Images />
  </div>
);

class ImagesBase extends Component {
  constructor(props) {
  super(props);
  this.state = {
  url: '',
  images: [],
  loading: false,
  };
  }
  addImage = (event, image, authUser) => {
    
    let userId = authUser.uid;
    let imageId = image.uid;

    let updates = {
      [`${imageId}`]: true,
    }
    this.props.firebase.userImages(userId).update(updates);
    event.preventDefault();
    };
  
  componentDidMount() {
    this.setState({ loading: true });
    this.props.firebase.images().on('value', snapshot => {
    const imageObject = snapshot.val();
    if (imageObject) {
      const imageList = Object.keys(imageObject).map(key => ({
        ...imageObject[key],
        uid: key,
        }));
        this.setState({
        images: imageList,
        loading: false,
        });
        } else {
        this.setState({ messages: null, loading: false });
        }
        });
        }

  componentWillUnmount() {
  this.props.firebase.images().off();
  }
  render() {
  const { images, loading } = this.state;
  return (
    <AuthUserContext.Consumer>
    {authUser => (
    <div>
    {loading && <div>Loading ...</div>}
    {images ? (
      <div className="row">
      {images.map(image => (
        <div className="col-sm-4">
        <div className="card">
        <img className="card-img-top" height="200" width="200" src={image.url} alt="Card-img" />
        <div className="card-body">
          <h5 className="card-title">Card title</h5>
          <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <Button variant="contained" type="submit" color="primary" onClick={event => this.addImage(event, image, authUser)}>
           Add 
          </Button>
        </div>
      </div>
      </div>
      ))}
      </div>
    ) : (
    <div>There are no messages ...</div>
    )}
    </div>
    )}
    </AuthUserContext.Consumer>
  );
  }
  }
  const Images = withFirebase(ImagesBase);

const condition = authUser =>
  authUser && authUser.roles.includes(ROLES.RETAILER);

  export default withAuthorization(condition)(RetailerPage);
