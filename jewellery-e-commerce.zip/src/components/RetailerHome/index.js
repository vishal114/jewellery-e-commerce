import React, { Component } from 'react';

import { AuthUserContext, withAuthorization } from '../Session';
import * as ROLES from '../../constants/roles';
import { withFirebase } from '../Firebase';


const RetailerHome = () => (
    <AuthUserContext.Consumer>
    {authUser => (
        <Images authUser={authUser} />
        )}
        </AuthUserContext.Consumer>
);

class ImagesBase extends Component {
  constructor(props) {
  super(props);
  this.state = {
  url:'',
  images: [],
  loading: false,
  };
  }

    componentDidMount() {
        this.setState({ loading: true });
        const imgList=[]
        this.props.firebase.userImages(this.props.authUser.uid).on('child_added', snapshot => {
          this.props.firebase.image(snapshot.key).once('value').then(imageSnap => {
            const imgObj= {...imageSnap.val(), key: snapshot.key}
            console.log(imgObj)
            imgList.push(imgObj)
          })
        })
        if(imgList)
        {this.setState({
          images: imgList,
          loading: false,
        });}
        else{
          this.setState({ images: null, loading: false });
        }
        
       
    }
    componentWillUnmount() {
        this.props.firebase.userImages().off();
        }

 
  render() {
  const { images, loading } = this.state;
  console.log(images)
  
  return (
    <div>
      {loading && <div>Loading ...</div>}
      {images ? (
        <div className="row">
          
          {images.map((image) => (
            
            
            <div className="col-sm-4" key={image.key}>
              <div className="card">
                <img
                  className="card-img-top"
                  height="200"
                  width="200"
                  src={image.url}
                  alt="Card-img"
                />
                <div className="card-body">
                  <h5 className="card-title">Card title</h5>
                  <p className="card-text">
                    Some quick example text to build on the card title
                    and make up the bulk of the card's content.
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
       ) : (
        <div>There are no messages ...</div>
      )}
    </div>
  );
  
  }
  }

  
  const Images = withFirebase(ImagesBase);

const condition = authUser =>
  authUser && authUser.roles.includes(ROLES.RETAILER);

  export default withAuthorization(condition)(RetailerHome);

  
  
  
