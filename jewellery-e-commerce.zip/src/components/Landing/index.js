import React from 'react';
import { Carousel } from 'react-bootstrap';
import image1 from '../../images/download1.jpg';
import image2 from '../../images/download2.jpg';
import image4 from '../../images/download4.jpg';

const Landing = () => (
  <div>
    <div className="container-fluid">
      <Carousel>
        <Carousel.Item interval={1000}>
          <img
            className="d-block w-100"
            src={image1}
            alt="image1"
            height="300"
          />
          <Carousel.Caption>
            <h3>Platinum Ring</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={1000}>
          <img
            className="d-block w-100"
            src={image2}
            alt="image2"
            height="300"
          />
          <Carousel.Caption>
            <h3>Golden Bangle</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={image4}
            alt="image3"
            height="300"
          />
          <Carousel.Caption>
            <h3>Diamond Ring</h3>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    </div>
  </div>
  // <div>
  //   <div
  //     id="carouselExampleControls"
  //     className="carousel slide"
  //     data-ride="carousel"
  //   >
  //     <div className="carousel-inner">
  //       <div className="carousel-item active">
  //         <img
  //           className="d-block w-100"
  //           src={image1}
  //           alt="First slide"
  //         />
  //       </div>
  //       <div className="carousel-item">
  //         <img
  //           className="d-block w-100"
  //           src={image2}
  //           alt="Second slide"
  //         />
  //       </div>
  //       <div className="carousel-item">
  //         <img
  //           className="d-block w-100"
  //           src={image4}
  //           alt="Third slide"
  //         />
  //       </div>
  //     </div>
  //     <a
  //       className="carousel-control-prev"
  //       href="#carouselExampleControls"
  //       role="button"
  //       data-slide="prev"
  //     >
  //       <span
  //         className="carousel-control-prev-icon"
  //         aria-hidden="true"
  //       ></span>
  //       <span className="sr-only">Previous</span>
  //     </a>
  //     <a
  //       className="carousel-control-next"
  //       href="#carouselExampleControls"
  //       role="button"
  //       data-slide="next"
  //     >
  //       <span
  //         className="carousel-control-next-icon"
  //         aria-hidden="true"
  //       ></span>
  //       <span className="sr-only">Next</span>
  //     </a>
  //   </div>
  // </div>
);

export default Landing;
