import React, { Component } from 'react';
import { compose } from 'recompose';
import { withFirebase } from '../Firebase';
import { AuthUserContext,withAuthorization } from '../Session';
import * as ROLES from '../../constants/roles';

class ManufacturerPage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      image: null,
      url: '',
    };
    this.handleChange = this
      .handleChange
      .bind(this);
      // this.handleUpload = this.handleUpload.bind(this);
  }
  handleChange = e => {
    if (e.target.files[0]) {
      const image = e.target.files[0];
      this.setState(() => ({image}));
    }
  }
  handleUpload = (event, authUser) => {
    const {image} = this.state;
    const uploadTask = this.props.firebase.storage.ref(`images/${image.name}`).put(image);
    uploadTask.on('state_changed', 
    (snapshot) => {
      // progrss function ....
      const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
      this.setState({progress});
    }, 
    (error) => {
         // error function ....
      console.log(error);
    }, 
  () => {
      // complete function ....
      this.props.firebase.storage.ref('images').child(image.name).getDownloadURL().then(url => {
          console.log(url);
          this.props.firebase.images().push({
            url: url,
            userId: authUser.uid,
            });


          this.setState({url});
          
      })
  });
  }


  render() {
    const style = {
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center'
    };
    

    return (
      <AuthUserContext.Consumer>
{authUser => (
        <div style={style}>
      <progress value={this.state.progress} max="100"/>
      <br/>
        <input type="file" onChange={this.handleChange}/>
        <button onClick={event => this.handleUpload(event, authUser)}>Upload</button>
        <br/>
        <img src={this.state.url || 'http://via.placeholder.com/400x300'} alt="Uploaded images" height="300" width="400"/>
      </div>
      )}
</AuthUserContext.Consumer>
    );
  }
}


const condition = authUser =>
  authUser && authUser.roles.includes(ROLES.MANUFACTURER);

  export default compose(
    withAuthorization(condition),
    withFirebase,
  )(ManufacturerPage);
