import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import Navigation from '../Navigation';
import LandingPage from '../Landing';
import SignUpPage from '../SignUp';
import SignInPage from '../SignIn';
import PasswordForgetPage from '../PasswordForget';
import HomePage from '../Home';
import AccountPage from '../Account';
import AdminPage from '../Admin';
import ManufacturerPage from '../Manufacturer';
import RetailerPage from '../Retailer';
import RetailerHome from '../RetailerHome';

import * as ROUTES from '../../constants/routes';
import { withAuthentication } from '../Session';
import CssBaseline from '@material-ui/core/CssBaseline';
import Container from '@material-ui/core/Container';


const App = () => (
  <React.Fragment>
      <CssBaseline />
      <Container maxWidth="m">
  <Router>
    <div>
      <Navigation />


      <Route exact path={ROUTES.LANDING} component={LandingPage} />
      <Route exact path={ROUTES.SIGN_UP} component={SignUpPage} />
      <Route exact path={ROUTES.SIGN_IN} component={SignInPage} />
      <Route
        exact
        path={ROUTES.PASSWORD_FORGET}
        component={PasswordForgetPage}
      />
      <Route exact path={ROUTES.HOME} component={HomePage} />
      <Route exact path={ROUTES.ACCOUNT} component={AccountPage} />
      <Route exact path={ROUTES.ADMIN} component={AdminPage} />
      <Route exact path={ROUTES.MANUFACTURER} component={ManufacturerPage} />
      <Route exact path={ROUTES.RETAILER} component={RetailerPage} />
      <Route exact path={ROUTES.RETAILERHOME} component={RetailerHome} />
    </div>
  </Router>
  </Container>
    </React.Fragment>
);

export default withAuthentication(App);
