import React, { Component } from 'react';
import './App.css';
import './index.css';
import { AuthUserContext, withAuthorization } from '../Session';
import { withFirebase } from '../Firebase';
import { Container } from '../Container';
const Nexmo = require('nexmo');

const nexmo = new Nexmo({});

const HomePage = () => {
  return (
    <div className="App">
      <Images />
    </div>
  );
};

class ImagesBase extends Component {
  constructor(props) {
    super(props);
    this.state = {
      url: '',
      images: [],
      loading: false,
    };
  }
  componentDidMount() {
    this.setState({ loading: true });
    this.props.firebase.images().on('value', (snapshot) => {
      const imageObject = snapshot.val();
      console.log(imageObject);
      if (imageObject) {
        const imageList = Object.keys(imageObject).map((key) => {
          return {
            ...imageObject[key],
            uid: key,
          };
        });
        this.setState({
          images: imageList,
          loading: false,
        });
      } else {
        this.setState({ images: null, loading: false });
      }
    });
  }

  componentWillUnmount() {
    this.props.firebase.images().off();
  }
  enquire = (event) => {
    const from = 'Vonage APIs';
    const to = '919876543210';
    const text =
      event.target.name.value +
      'has enquired for your jewellery. Mobile number: ' +
      event.target.mobile.value;

    nexmo.message.sendSms(from, to, text);
    event.preventDefault(event);
  };
  render() {
    const { images, loading } = this.state;
    console.log(typeof images);
    return (
      <AuthUserContext.Consumer>
        {(authUser) => (
          <div>
            {loading && <div>Loading ...</div>}
            {images ? (
              <div className="row">
                {images.map((image) => (
                  <div className="col-sm-4" key={image.uid}>
                    <div className="card">
                      <img
                        className="card-img-top"
                        height="200"
                        width="200"
                        src={image.url}
                        alt="Card-img"
                      />
                      <div className="card-body">
                        <h5 className="card-title">Card title</h5>
                        <p className="card-text">
                          Some quick example text to build on the card
                          title and make up the bulk of the card's
                          content.
                        </p>
                        <Container
                          triggerText="Ask for Price"
                          onSubmit={(event) => this.enquire(event)}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div>There are no messages ...</div>
            )}
          </div>
        )}
      </AuthUserContext.Consumer>
    );
  }
}
const Images = withFirebase(ImagesBase);

const condition = (authUser) => !!authUser;

export default withAuthorization(condition)(HomePage);
