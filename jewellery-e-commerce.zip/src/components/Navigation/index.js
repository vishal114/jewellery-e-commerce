import React from 'react';
import { Link } from 'react-router-dom';
import {Navbar, Form, FormControl, Nav, Button } from 'react-bootstrap';
import { AuthUserContext } from '../Session';
import SignOutButton from '../SignOut';
import * as ROUTES from '../../constants/routes';
import * as ROLES from '../../constants/roles';






const Navigation = () => (
  <AuthUserContext.Consumer>
    {authUser =>
      authUser ? (
        <NavigationAuth authUser={authUser} />
      ) : (
        <NavigationNonAuth />
      )
    }
  </AuthUserContext.Consumer>
);

const NavigationAuth = ({ authUser }) => (
  <Navbar bg="primary" variant="dark">
    <Navbar.Brand href="#home">Navbar</Navbar.Brand>
    <Nav className="mr-auto">
      <Nav.Link href={ROUTES.LANDING}>Landing</Nav.Link>
      <Nav.Link href={ROUTES.HOME}>Home</Nav.Link>
      {authUser.roles.includes(ROLES.ADMIN) && (
        <Nav.Link href={ROUTES.ADMIN}>Admin</Nav.Link>
      )}
      {authUser.roles.includes(ROLES.MANUFACTURER) && (
        <Nav.Link href={ROUTES.MANUFACTURER}>Manufacturer</Nav.Link>
      )}
      {authUser.roles.includes(ROLES.RETAILER) && (
        <Nav.Link href={ROUTES.RETAILER}>Retailer</Nav.Link>
      )}
      {authUser.roles.includes(ROLES.RETAILER) && (
        <Nav.Link href={ROUTES.RETAILERHOME}>RetailerHome</Nav.Link>
      )}
      <SignOutButton />
    </Nav>
    <Form inline>
      <FormControl type="text" placeholder="Search" className="mr-sm-2" />
      <Button variant="contained" color="primary">Search</Button>
    </Form>
  </Navbar>
);

const NavigationNonAuth = () => (
<Navbar bg="primary" className="container" variant="dark">
    <Navbar.Brand href="#home">Navbar</Navbar.Brand>
    <Nav className="mr-auto">
      <Nav.Link href={ROUTES.LANDING}>Landing</Nav.Link>
      <Nav.Link href={ROUTES.SIGN_IN}>Sign In</Nav.Link>
    </Nav>
    <Form inline>
      <FormControl type="text" placeholder="Search" className="mr-sm-2" />
      <Button variant="outline-light">Search</Button>
    </Form>
  </Navbar>

);

export default Navigation;
